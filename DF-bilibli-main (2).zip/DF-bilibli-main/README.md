# DF-bilibli
Distraction Free BiliBili
用于过滤B站内的广告，推荐，评论。
